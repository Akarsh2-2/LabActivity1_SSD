Question-1
Solution- We use awk command to sort out